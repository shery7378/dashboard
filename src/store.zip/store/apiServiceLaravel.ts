//store/apiFetchLaravel.ts
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { BaseQueryFn, FetchArgs, FetchBaseQueryError, FetchBaseQueryMeta } from '@reduxjs/toolkit/query';

export const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://api.multikonnect.test:8000';
export const globalHeaders = {
  'Content-Type': 'application/json',
  'Origin': 'http://vendor.multikonnect.test:3001',
};

const baseQuery: BaseQueryFn<string | FetchArgs, unknown, FetchBaseQueryError, object, FetchBaseQueryMeta> = async (
  args,
  api,
  extraOptions
) => {
  // Fetch Sanctum CSRF cookie
  await fetch(`${API_BASE_URL}/sanctum/csrf-cookie`, {
    credentials: 'include',
    headers: { Origin: globalHeaders['Origin'] },
  });

  // Get NextAuth session for token
  const session = await import('next-auth/react').then(({ getSession }) => getSession());
  const token = session?.accessToken;

  const result = await fetchBaseQuery({
    baseUrl: API_BASE_URL,
    credentials: 'include',
    prepareHeaders: (headers) => {
      Object.entries(globalHeaders).forEach(([key, value]) => {
        headers.set(key, value);
      });
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  })(args, api, extraOptions);

  if (result.error && result.error.status === 401) {
    console.error('Unauthorized request:', result.error);
    // Add token refresh logic here if needed
  }

  return result;
};

export const apiServiceLaravel = createApi({
  baseQuery,
  endpoints: () => ({}),
  reducerPath: 'apiServiceLaravel',
});

export default apiServiceLaravel;